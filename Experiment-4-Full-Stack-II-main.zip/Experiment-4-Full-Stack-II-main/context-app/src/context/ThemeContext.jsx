import { useUser } from "../context/UserContext";
import { useTheme } from "../context/ThemeContext";

export default function Header() {
  const { user, isLoggedIn, logout } = useUser();
  const { theme, toggleTheme } = useTheme();

  return (
    <header>
      <button onClick={toggleTheme}>{theme}</button>
      {isLoggedIn ? (
        <div>
          <p>Welcome {user.name}</p>
          <button onClick={logout}>Logout</button>
        </div>
      ) : (
        <p>Please Login</p>
      )}
    </header>
  );
}
