import { useUser } from "../context/UserContext";

export default function LoginForm() {
  const { login } = useUser();

  const handleSubmit = (e) => {
    e.preventDefault();
    login({ name: "John Doe", email: "john@example.com" });
  };

  return (
    <form onSubmit={handleSubmit}>
      <button type="submit">Login</button>
    </form>
  );
}
