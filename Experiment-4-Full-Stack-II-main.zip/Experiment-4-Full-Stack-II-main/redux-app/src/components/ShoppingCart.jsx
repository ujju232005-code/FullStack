import { useDispatch, useSelector } from "react-redux";
import { addItem, removeItem } from "../store/slices/cartSlice";

export default function ShoppingCart() {
  const { items, total } = useSelector(state => state.cart);
  const dispatch = useDispatch();

  return (
    <div>
      <button onClick={() => dispatch(addItem({ id: 1, name: "Item", price: 100 }))}>
        Add Item
      </button>
      {items.map(item => (
        <div key={item.id}>
          <p>{item.name}</p>
          <button onClick={() => dispatch(removeItem(item.id))}>Remove</button>
        </div>
      ))}
      <h3>Total: {total}</h3>
    </div>
  );
}
