import Counter from "./components/Counter";
import ShoppingCart from "./components/ShoppingCart";

export default function App() {
  return (
    <>
      <Counter />
      <ShoppingCart />
    </>
  );
}
